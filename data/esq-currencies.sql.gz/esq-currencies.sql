--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: admin_tools_dashboard_preferences; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE admin_tools_dashboard_preferences (
    id integer NOT NULL,
    user_id integer NOT NULL,
    data text NOT NULL,
    dashboard_id character varying(100) NOT NULL
);


ALTER TABLE public.admin_tools_dashboard_preferences OWNER TO web;

--
-- Name: admin_tools_dashboard_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE admin_tools_dashboard_preferences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.admin_tools_dashboard_preferences_id_seq OWNER TO web;

--
-- Name: admin_tools_dashboard_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE admin_tools_dashboard_preferences_id_seq OWNED BY admin_tools_dashboard_preferences.id;


--
-- Name: admin_tools_dashboard_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('admin_tools_dashboard_preferences_id_seq', 2, true);


--
-- Name: admin_tools_menu_bookmark; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE admin_tools_menu_bookmark (
    id integer NOT NULL,
    user_id integer NOT NULL,
    url character varying(255) NOT NULL,
    title character varying(255) NOT NULL
);


ALTER TABLE public.admin_tools_menu_bookmark OWNER TO web;

--
-- Name: admin_tools_menu_bookmark_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE admin_tools_menu_bookmark_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.admin_tools_menu_bookmark_id_seq OWNER TO web;

--
-- Name: admin_tools_menu_bookmark_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE admin_tools_menu_bookmark_id_seq OWNED BY admin_tools_menu_bookmark.id;


--
-- Name: admin_tools_menu_bookmark_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('admin_tools_menu_bookmark_id_seq', 1, false);


--
-- Name: attachments_attachment; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE attachments_attachment (
    id integer NOT NULL,
    content_type_id integer NOT NULL,
    object_id integer NOT NULL,
    creator_id integer NOT NULL,
    attachment_file character varying(100) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    CONSTRAINT attachments_attachment_object_id_check CHECK ((object_id >= 0))
);


ALTER TABLE public.attachments_attachment OWNER TO web;

--
-- Name: attachments_attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE attachments_attachment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.attachments_attachment_id_seq OWNER TO web;

--
-- Name: attachments_attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE attachments_attachment_id_seq OWNED BY attachments_attachment.id;


--
-- Name: attachments_attachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('attachments_attachment_id_seq', 1, false);


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO web;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO web;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO web;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO web;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO web;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO web;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('auth_permission_id_seq', 59, true);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    password character varying(128) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    is_superuser boolean NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO web;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO web;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO web;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO web;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('auth_user_id_seq', 1, true);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO web;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO web;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    content_type_id integer,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO web;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO web;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 12, true);


--
-- Name: django_comment_flags; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE django_comment_flags (
    id integer NOT NULL,
    user_id integer NOT NULL,
    comment_id integer NOT NULL,
    flag character varying(30) NOT NULL,
    flag_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_comment_flags OWNER TO web;

--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE django_comment_flags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_comment_flags_id_seq OWNER TO web;

--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE django_comment_flags_id_seq OWNED BY django_comment_flags.id;


--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('django_comment_flags_id_seq', 1, false);


--
-- Name: django_comments; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE django_comments (
    id integer NOT NULL,
    content_type_id integer NOT NULL,
    object_pk text NOT NULL,
    site_id integer NOT NULL,
    user_id integer,
    user_name character varying(50) NOT NULL,
    user_email character varying(75) NOT NULL,
    user_url character varying(200) NOT NULL,
    comment text NOT NULL,
    submit_date timestamp with time zone NOT NULL,
    ip_address inet,
    is_public boolean NOT NULL,
    is_removed boolean NOT NULL
);


ALTER TABLE public.django_comments OWNER TO web;

--
-- Name: django_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE django_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_comments_id_seq OWNER TO web;

--
-- Name: django_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE django_comments_id_seq OWNED BY django_comments.id;


--
-- Name: django_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('django_comments_id_seq', 1, false);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO web;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO web;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('django_content_type_id_seq', 19, true);


--
-- Name: django_flatpage; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE django_flatpage (
    id integer NOT NULL,
    url character varying(100) NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    enable_comments boolean NOT NULL,
    template_name character varying(70) NOT NULL,
    registration_required boolean NOT NULL
);


ALTER TABLE public.django_flatpage OWNER TO web;

--
-- Name: django_flatpage_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE django_flatpage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_flatpage_id_seq OWNER TO web;

--
-- Name: django_flatpage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE django_flatpage_id_seq OWNED BY django_flatpage.id;


--
-- Name: django_flatpage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('django_flatpage_id_seq', 1, false);


--
-- Name: django_flatpage_sites; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE django_flatpage_sites (
    id integer NOT NULL,
    flatpage_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.django_flatpage_sites OWNER TO web;

--
-- Name: django_flatpage_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE django_flatpage_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_flatpage_sites_id_seq OWNER TO web;

--
-- Name: django_flatpage_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE django_flatpage_sites_id_seq OWNED BY django_flatpage_sites.id;


--
-- Name: django_flatpage_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('django_flatpage_sites_id_seq', 1, false);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO web;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO web;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO web;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Name: money_client; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE money_client (
    id integer NOT NULL,
    name character varying(250) NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.money_client OWNER TO web;

--
-- Name: money_client_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE money_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.money_client_id_seq OWNER TO web;

--
-- Name: money_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE money_client_id_seq OWNED BY money_client.id;


--
-- Name: money_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('money_client_id_seq', 1, true);


--
-- Name: money_currency; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE money_currency (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(3) NOT NULL,
    "numeric" character varying(3) NOT NULL,
    is_active boolean NOT NULL
);


ALTER TABLE public.money_currency OWNER TO web;

--
-- Name: money_currency_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE money_currency_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.money_currency_id_seq OWNER TO web;

--
-- Name: money_currency_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE money_currency_id_seq OWNED BY money_currency.id;


--
-- Name: money_currency_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('money_currency_id_seq', 158, true);


--
-- Name: money_exchangerate; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE money_exchangerate (
    id integer NOT NULL,
    from_curr_id integer NOT NULL,
    to_curr_id integer NOT NULL,
    rate numeric(8,6) NOT NULL,
    date_added timestamp with time zone NOT NULL,
    effective_date date NOT NULL
);


ALTER TABLE public.money_exchangerate OWNER TO web;

--
-- Name: money_exchangerate_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE money_exchangerate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.money_exchangerate_id_seq OWNER TO web;

--
-- Name: money_exchangerate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE money_exchangerate_id_seq OWNED BY money_exchangerate.id;


--
-- Name: money_exchangerate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('money_exchangerate_id_seq', 1, true);


--
-- Name: money_portfolio; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE money_portfolio (
    id integer NOT NULL,
    client_id integer NOT NULL,
    name character varying(250) NOT NULL,
    description text NOT NULL,
    starting_balance numeric(8,2)
);


ALTER TABLE public.money_portfolio OWNER TO web;

--
-- Name: money_portfolio_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE money_portfolio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.money_portfolio_id_seq OWNER TO web;

--
-- Name: money_portfolio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE money_portfolio_id_seq OWNED BY money_portfolio.id;


--
-- Name: money_portfolio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('money_portfolio_id_seq', 2, true);


--
-- Name: money_transaction; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE money_transaction (
    id integer NOT NULL,
    amount numeric(8,2) NOT NULL,
    exchange_rate_id integer NOT NULL,
    portfolio_id integer NOT NULL,
    date_added timestamp with time zone NOT NULL,
    notes text NOT NULL,
    "order" integer NOT NULL,
    balance_amount numeric(8,2) NOT NULL,
    short_description character varying(50) NOT NULL
);


ALTER TABLE public.money_transaction OWNER TO web;

--
-- Name: money_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE money_transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.money_transaction_id_seq OWNER TO web;

--
-- Name: money_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE money_transaction_id_seq OWNED BY money_transaction.id;


--
-- Name: money_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('money_transaction_id_seq', 3, true);


--
-- Name: south_migrationhistory; Type: TABLE; Schema: public; Owner: web; Tablespace: 
--

CREATE TABLE south_migrationhistory (
    id integer NOT NULL,
    app_name character varying(255) NOT NULL,
    migration character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.south_migrationhistory OWNER TO web;

--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE; Schema: public; Owner: web
--

CREATE SEQUENCE south_migrationhistory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.south_migrationhistory_id_seq OWNER TO web;

--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: web
--

ALTER SEQUENCE south_migrationhistory_id_seq OWNED BY south_migrationhistory.id;


--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: web
--

SELECT pg_catalog.setval('south_migrationhistory_id_seq', 8, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY admin_tools_dashboard_preferences ALTER COLUMN id SET DEFAULT nextval('admin_tools_dashboard_preferences_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY admin_tools_menu_bookmark ALTER COLUMN id SET DEFAULT nextval('admin_tools_menu_bookmark_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY attachments_attachment ALTER COLUMN id SET DEFAULT nextval('attachments_attachment_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_comment_flags ALTER COLUMN id SET DEFAULT nextval('django_comment_flags_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_comments ALTER COLUMN id SET DEFAULT nextval('django_comments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_flatpage ALTER COLUMN id SET DEFAULT nextval('django_flatpage_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_flatpage_sites ALTER COLUMN id SET DEFAULT nextval('django_flatpage_sites_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY money_client ALTER COLUMN id SET DEFAULT nextval('money_client_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY money_currency ALTER COLUMN id SET DEFAULT nextval('money_currency_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY money_exchangerate ALTER COLUMN id SET DEFAULT nextval('money_exchangerate_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY money_portfolio ALTER COLUMN id SET DEFAULT nextval('money_portfolio_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY money_transaction ALTER COLUMN id SET DEFAULT nextval('money_transaction_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: web
--

ALTER TABLE ONLY south_migrationhistory ALTER COLUMN id SET DEFAULT nextval('south_migrationhistory_id_seq'::regclass);


--
-- Data for Name: admin_tools_dashboard_preferences; Type: TABLE DATA; Schema: public; Owner: web
--

COPY admin_tools_dashboard_preferences (id, user_id, data, dashboard_id) FROM stdin;
1	1	{}	dashboard
2	1	{}	money-dashboard
\.


--
-- Data for Name: admin_tools_menu_bookmark; Type: TABLE DATA; Schema: public; Owner: web
--

COPY admin_tools_menu_bookmark (id, user_id, url, title) FROM stdin;
\.


--
-- Data for Name: attachments_attachment; Type: TABLE DATA; Schema: public; Owner: web
--

COPY attachments_attachment (id, content_type_id, object_id, creator_id, attachment_file, created, modified) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: web
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: web
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: web
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add permission	2	add_permission
5	Can change permission	2	change_permission
6	Can delete permission	2	delete_permission
7	Can add group	3	add_group
8	Can change group	3	change_group
9	Can delete group	3	delete_group
10	Can add user	4	add_user
11	Can change user	4	change_user
12	Can delete user	4	delete_user
13	Can add comment	5	add_comment
14	Can change comment	5	change_comment
15	Can delete comment	5	delete_comment
16	Can moderate comments	5	can_moderate
17	Can add comment flag	6	add_commentflag
18	Can change comment flag	6	change_commentflag
19	Can delete comment flag	6	delete_commentflag
20	Can add content type	7	add_contenttype
21	Can change content type	7	change_contenttype
22	Can delete content type	7	delete_contenttype
23	Can add session	8	add_session
24	Can change session	8	change_session
25	Can delete session	8	delete_session
26	Can add site	9	add_site
27	Can change site	9	change_site
28	Can delete site	9	delete_site
29	Can add flat page	10	add_flatpage
30	Can change flat page	10	change_flatpage
31	Can delete flat page	10	delete_flatpage
32	Can add attachment	11	add_attachment
33	Can change attachment	11	change_attachment
34	Can delete attachment	11	delete_attachment
35	Can delete foreign attachments	11	delete_foreign_attachments
36	Can add migration history	12	add_migrationhistory
37	Can change migration history	12	change_migrationhistory
38	Can delete migration history	12	delete_migrationhistory
39	Can add client	13	add_client
40	Can change client	13	change_client
41	Can delete client	13	delete_client
42	Can add portfolio	14	add_portfolio
43	Can change portfolio	14	change_portfolio
44	Can delete portfolio	14	delete_portfolio
45	Can add currency	15	add_currency
46	Can change currency	15	change_currency
47	Can delete currency	15	delete_currency
48	Can add exchange rate	16	add_exchangerate
49	Can change exchange rate	16	change_exchangerate
50	Can delete exchange rate	16	delete_exchangerate
51	Can add transaction	17	add_transaction
52	Can change transaction	17	change_transaction
53	Can delete transaction	17	delete_transaction
54	Can add bookmark	18	add_bookmark
55	Can change bookmark	18	change_bookmark
56	Can delete bookmark	18	delete_bookmark
57	Can add dashboard preferences	19	add_dashboardpreferences
58	Can change dashboard preferences	19	change_dashboardpreferences
59	Can delete dashboard preferences	19	delete_dashboardpreferences
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: web
--

COPY auth_user (id, username, first_name, last_name, email, password, is_staff, is_active, is_superuser, last_login, date_joined) FROM stdin;
1	pk			pk@uberbits.co	pbkdf2_sha256$10000$NWqmZLWe871I$ITURSZEmzDQ5VHDsiziSKPhzcG6HrTAXijBwKcY9O+g=	t	t	t	2012-08-20 07:11:43.818816-04	2012-05-02 10:46:46.423693-04
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: web
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: web
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: web
--

COPY django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message) FROM stdin;
1	2012-05-02 11:23:47.25018-04	1	15	126	US Dollar <USD>	2	Changed is_active.
2	2012-05-02 11:23:58.484068-04	1	15	114	Euro <EUR>	2	Changed is_active.
3	2012-05-02 11:28:52.406587-04	1	13	1	test client one	1	
4	2012-05-02 11:43:43.441543-04	1	16	1	EUR to USD at 1.35	1	
5	2012-05-02 11:46:39.596161-04	1	17	1	101 at 1.35	1	
6	2012-05-02 11:51:52.407633-04	1	17	2	500 at 1.35	1	
7	2012-05-02 11:52:35.303591-04	1	14	2	portfolio two	1	
8	2012-05-02 12:44:24.566634-04	1	17	1	101.00 at 1.35	2	Changed order.
9	2012-05-02 12:44:31.683448-04	1	17	2	500.00 at 1.35	2	Changed order.
10	2012-05-02 13:04:51.423475-04	1	17	3	1000.00 at 1.35	3	
11	2012-05-03 11:34:18.592091-04	1	17	1	-101.00 at 1.35	2	Changed amount.
12	2012-05-03 11:36:44.355336-04	1	14	1	portfolio for test client one	2	Changed starting_balance.
\.


--
-- Data for Name: django_comment_flags; Type: TABLE DATA; Schema: public; Owner: web
--

COPY django_comment_flags (id, user_id, comment_id, flag, flag_date) FROM stdin;
\.


--
-- Data for Name: django_comments; Type: TABLE DATA; Schema: public; Owner: web
--

COPY django_comments (id, content_type_id, object_pk, site_id, user_id, user_name, user_email, user_url, comment, submit_date, ip_address, is_public, is_removed) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: web
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
1	log entry	admin	logentry
2	permission	auth	permission
3	group	auth	group
4	user	auth	user
5	comment	comments	comment
6	comment flag	comments	commentflag
7	content type	contenttypes	contenttype
8	session	sessions	session
9	site	sites	site
10	flat page	flatpages	flatpage
11	attachment	attachments	attachment
12	migration history	south	migrationhistory
13	client	money	client
14	portfolio	money	portfolio
15	currency	money	currency
16	exchange rate	money	exchangerate
17	transaction	money	transaction
18	bookmark	menu	bookmark
19	dashboard preferences	dashboard	dashboardpreferences
\.


--
-- Data for Name: django_flatpage; Type: TABLE DATA; Schema: public; Owner: web
--

COPY django_flatpage (id, url, title, content, enable_comments, template_name, registration_required) FROM stdin;
\.


--
-- Data for Name: django_flatpage_sites; Type: TABLE DATA; Schema: public; Owner: web
--

COPY django_flatpage_sites (id, flatpage_id, site_id) FROM stdin;
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: web
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
413f878052c26768020aa2cc6d1bf716	NTUxZTFhNGI2ODE4NTNjZmU5YTAwY2UyYzlmMDNmMGE3YWNhNTVlODqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAXUu\n	2012-05-16 12:12:21.023294-04
21a9ec7e318e1b9a341105affe9d88ef	NTUxZTFhNGI2ODE4NTNjZmU5YTAwY2UyYzlmMDNmMGE3YWNhNTVlODqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAXUu\n	2012-09-03 07:11:43.837241-04
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: web
--

COPY django_site (id, domain, name) FROM stdin;
1	example.com	example.com
\.


--
-- Data for Name: money_client; Type: TABLE DATA; Schema: public; Owner: web
--

COPY money_client (id, name, description) FROM stdin;
1	test client one	descr
\.


--
-- Data for Name: money_currency; Type: TABLE DATA; Schema: public; Owner: web
--

COPY money_currency (id, name, code, "numeric", is_active) FROM stdin;
12	Pula	BWP	072	f
126	US Dollar	USD	840	t
114	Euro	EUR	978	t
1	Algerian Dinar	DZD	012	f
2	Ghana Cedi	GHS	936	f
3	Egyptian Pound	EGP	818	f
4	Bulgarian Lev	BGN	975	f
5	Bermudian Dollar (customarily known as Bermuda Dollar)	BMD	060	f
6	Philippine Peso	PHP	608	f
7	European Unit of Account 17(E.U.A.-17)	XBD	958	f
8	Bond Markets Units European Composite Unit (EURCO)	XBA	955	f
9	Danish Krone	DKK	208	f
10	European Unit of Account 9(E.U.A.-9)	XBC	957	f
11	European Monetary Unit (E.M.U.-6)	XBB	956	f
13	Lebanese Pound	LBP	422	f
14	Tanzanian Shilling	TZS	834	f
15	Dong	VND	704	f
16	Kwanza	AOA	973	f
17	Riel	KHR	116	f
18	Malaysian Ringgit	MYR	458	f
19	Cayman Islands Dollar	KYD	136	f
20	Libyan Dinar	LYD	434	f
21	Hryvnia	UAH	980	f
22	Jordanian Dinar	JOD	400	f
23	Aruban Guilder	AWG	533	f
24	Saudi Riyal	SAR	682	f
25	Brunei Dollar	BND	096	f
26	Hong Kong Dollar	HKD	344	f
27	Swiss Franc	CHF	756	f
28	Gibraltar Pound	GIP	292	f
29	Belarussian Ruble	BYR	974	f
30	Gold	XAU	959	f
31	Palladium	XPD	964	f
32	Ouguiya	MRO	478	f
33	Croatian Kuna	HRK	191	f
34	Djibouti Franc	DJF	262	f
35	Baht	THB	764	f
36	Silver	XAG	961	f
37	Iceland Krona	ISK	352	f
38	Cordoba Oro	NIO	558	f
39	Kip	LAK	418	f
40	The codes assigned for transactions where no currency is involved are:	XYZ	999	f
41	Syrian Pound	SYP	760	f
42	Moroccan Dirham	MAD	504	f
43	Metical	MZN	943	f
44	Trinidad and Tobago Dollar	TTD	780	f
45	Rand	ZAR	710	f
46	Guarani	PYG	600	f
47	Naira	NGN	566	f
48	Zimbabwe Dollar	ZWD	716	f
49	Costa Rican Colon	CRC	188	f
50	UAE Dirham	AED	784	f
51	Pound Sterling	GBP	826	f
52	Kwacha	MWK	454	f
53	Sri Lanka Rupee	LKR	144	f
54	Slovak Koruna	SKK	703	f
55	Pakistan Rupee	PKR	586	f
56	Forint	HUF	348	f
57	Lilangeni	SZL	748	f
58	Convertible Marks	BAM	977	f
59	Tugrik	MNT	496	f
60	Armenian Dram	AMD	051	f
61	Uganda Shilling	UGX	800	f
62	Qatari Rial	QAR	634	f
63	SDR	XDR	960	f
64	Jamaican Dollar	JMD	388	f
65	Seychelles Rupee	SCR	690	f
66	Saint Helena Pound	SHP	654	f
67	Afghani	AFN	971	f
68	Kyat	MMK	104	f
69	North Korean Won	KPW	408	f
70	Denar	MKD	807	f
71	New Turkish Lira	TRY	949	f
72	Taka	BDT	050	f
73	Yemeni Rial	YER	886	f
74	Malagasy Ariary	MGA	969	f
75	Netherlands Antillian Guilder	ANG	532	f
76	Liberian Dollar	LRD	430	f
77	East Caribbean Dollar	XCD	951	f
78	Norwegian Krone	NOK	578	f
79	Pataca	MOP	446	f
80	Indian Rupee	INR	356	f
81	Czech Koruna	CZK	203	f
82	Somoni	TJS	972	f
83	Nepalese Rupee	NPR	524	f
84	Comoro Franc	KMF	174	f
85	Mauritius Rupee	MUR	480	f
86	Rupiah	IDR	360	f
87	Lempira	HNL	340	f
88	Ethiopian Birr	ETB	230	f
89	Fiji Dollar	FJD	242	f
90	Vatu	VUV	548	f
91	Nuevo Sol	PEN	604	f
92	Belize Dollar	BZD	084	f
93	New Israeli Sheqel	ILS	376	f
94	Dominican Peso	DOP	214	f
95	Manat	TMM	795	f
96	New Taiwan Dollar	TWD	901	f
97	Gold-Franc	XFO	Nil	f
98	Platinum	XPT	962	f
99	Bahamian Dollar	BSD	044	f
100	Swedish Krona	SEK	752	f
101	Kwacha	ZMK	894	f
102	Rufiyaa	MVR	462	f
103	Moldovan Leu	MDL	498	f
104	Codes specifically reserved for testing purposes	XTS	963	f
105	Australian Dollar	AUD	036	f
106	Surinam Dollar	SRD	968	f
107	Cuban Peso	CUP	192	f
108	Barbados Dollar	BBD	052	f
109	Won	KRW	410	f
110	Dalasi	GMD	270	f
111	Bolivar Fuerte	VEF	937	f
112	Quetzal	GTQ	320	f
113	Lari	GEL	981	f
115	Lek	ALL	008	f
116	Rwanda Franc	RWF	646	f
117	Tenge	KZT	398	f
118	CFP Franc	XPF	953	f
119	Russian Ruble	RUB	643	f
120	UIC-Franc	XFU	Nil	f
121	Rial Omani	OMR	512	f
122	Brazilian Real	BRL	986	f
123	Solomon Islands Dollar	SBD	090	f
124	Zloty	PLN	985	f
125	Kenyan Shilling	KES	404	f
127	Kroon	EEK	233	f
128	Azerbaijanian Manat	AZN	944	f
129	Paanga	TOP	776	f
130	Guinea Franc	GNF	324	f
131	Tala	WST	882	f
132	Iraqi Dinar	IQD	368	f
133	Nakfa	ERN	232	f
134	Cape Verde Escudo	CVE	132	f
135	Canadian Dollar	CAD	124	f
136	Guyana Dollar	GYD	328	f
137	Kuwaiti Dinar	KWD	414	f
138	Burundi Franc	BIF	108	f
139	Kina	PGK	598	f
140	Somali Shilling	SOS	706	f
141	Singapore Dollar	SGD	702	f
142	Uzbekistan Sum	UZS	860	f
143	Dobra	STD	678	f
144	Iranian Rial	IRR	364	f
145	Yuan Renminbi	CNY	156	f
146	Leone	SLL	694	f
147	Tunisian Dinar	TND	788	f
148	New Zealand Dollar	NZD	554	f
149	Falkland Islands Pound	FKP	238	f
150	Latvian Lats	LVL	428	f
151	Som	KGS	417	f
152	Argentine Peso	ARS	032	f
153	New Leu	RON	946	f
154	Serbian Dinar	RSD	941	f
155	Bahraini Dinar	BHD	048	f
156	Lithuanian Litas	LTL	440	f
157	Yen	JPY	392	f
158	Sudanese Pound	SDG	938	f
\.


--
-- Data for Name: money_exchangerate; Type: TABLE DATA; Schema: public; Owner: web
--

COPY money_exchangerate (id, from_curr_id, to_curr_id, rate, date_added, effective_date) FROM stdin;
1	114	126	1.350000	2012-05-02 11:43:43.434769-04	2012-08-20
\.


--
-- Data for Name: money_portfolio; Type: TABLE DATA; Schema: public; Owner: web
--

COPY money_portfolio (id, client_id, name, description, starting_balance) FROM stdin;
2	1	portfolio two	descrrr	\N
1	1	portfolio for test client one	descr portf	3000.00
\.


--
-- Data for Name: money_transaction; Type: TABLE DATA; Schema: public; Owner: web
--

COPY money_transaction (id, amount, exchange_rate_id, portfolio_id, date_added, notes, "order", balance_amount, short_description) FROM stdin;
1	-101.00	1	1	2012-05-02 11:46:39.593498-04	notes.....	1	2899.00	
2	500.00	1	1	2012-05-02 11:51:52.405555-04	notesss	2	3399.00	
\.


--
-- Data for Name: south_migrationhistory; Type: TABLE DATA; Schema: public; Owner: web
--

COPY south_migrationhistory (id, app_name, migration, applied) FROM stdin;
1	menu	0001_initial	2012-05-02 10:46:59.142963-04
2	dashboard	0001_initial	2012-05-02 10:47:04.62385-04
3	dashboard	0002_auto__add_field_dashboardpreferences_dashboard_id	2012-05-02 10:47:04.698609-04
4	money	0001_initial	2012-05-02 10:47:25.902901-04
5	money	0002_auto__add_field_transaction_order	2012-05-02 12:38:11.831945-04
6	money	0003_auto__add_field_transaction_balance_amount	2012-05-02 13:13:41.107316-04
7	money	0004_auto__add_field_portfolio_starting_balance__add_field_transaction_shor	2012-05-03 11:07:39.76882-04
8	money	0005_auto__add_field_exchangerate_effective_date__chg_field_exchangerate_ra	2012-08-20 07:27:51.490462-04
\.


--
-- Name: admin_tools_dashboard_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY admin_tools_dashboard_preferences
    ADD CONSTRAINT admin_tools_dashboard_preferences_pkey PRIMARY KEY (id);


--
-- Name: admin_tools_menu_bookmark_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY admin_tools_menu_bookmark
    ADD CONSTRAINT admin_tools_menu_bookmark_pkey PRIMARY KEY (id);


--
-- Name: attachments_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY attachments_attachment
    ADD CONSTRAINT attachments_attachment_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_key; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_key; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_key; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_key; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_comment_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY django_comment_flags
    ADD CONSTRAINT django_comment_flags_pkey PRIMARY KEY (id);


--
-- Name: django_comment_flags_user_id_key; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY django_comment_flags
    ADD CONSTRAINT django_comment_flags_user_id_key UNIQUE (user_id, comment_id, flag);


--
-- Name: django_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY django_comments
    ADD CONSTRAINT django_comments_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_key; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_key UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_flatpage_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY django_flatpage
    ADD CONSTRAINT django_flatpage_pkey PRIMARY KEY (id);


--
-- Name: django_flatpage_sites_flatpage_id_key; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY django_flatpage_sites
    ADD CONSTRAINT django_flatpage_sites_flatpage_id_key UNIQUE (flatpage_id, site_id);


--
-- Name: django_flatpage_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY django_flatpage_sites
    ADD CONSTRAINT django_flatpage_sites_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: money_client_name_key; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY money_client
    ADD CONSTRAINT money_client_name_key UNIQUE (name);


--
-- Name: money_client_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY money_client
    ADD CONSTRAINT money_client_pkey PRIMARY KEY (id);


--
-- Name: money_currency_code_key; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY money_currency
    ADD CONSTRAINT money_currency_code_key UNIQUE (code);


--
-- Name: money_currency_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY money_currency
    ADD CONSTRAINT money_currency_pkey PRIMARY KEY (id);


--
-- Name: money_exchangerate_from_curr_id_key; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY money_exchangerate
    ADD CONSTRAINT money_exchangerate_from_curr_id_key UNIQUE (from_curr_id, rate);


--
-- Name: money_exchangerate_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY money_exchangerate
    ADD CONSTRAINT money_exchangerate_pkey PRIMARY KEY (id);


--
-- Name: money_exchangerate_to_curr_id_key; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY money_exchangerate
    ADD CONSTRAINT money_exchangerate_to_curr_id_key UNIQUE (to_curr_id, rate);


--
-- Name: money_portfolio_name_key; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY money_portfolio
    ADD CONSTRAINT money_portfolio_name_key UNIQUE (name);


--
-- Name: money_portfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY money_portfolio
    ADD CONSTRAINT money_portfolio_pkey PRIMARY KEY (id);


--
-- Name: money_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY money_transaction
    ADD CONSTRAINT money_transaction_pkey PRIMARY KEY (id);


--
-- Name: south_migrationhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: web; Tablespace: 
--

ALTER TABLE ONLY south_migrationhistory
    ADD CONSTRAINT south_migrationhistory_pkey PRIMARY KEY (id);


--
-- Name: admin_tools_dashboard_preferences_user_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX admin_tools_dashboard_preferences_user_id ON admin_tools_dashboard_preferences USING btree (user_id);


--
-- Name: admin_tools_menu_bookmark_user_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX admin_tools_menu_bookmark_user_id ON admin_tools_menu_bookmark USING btree (user_id);


--
-- Name: attachments_attachment_content_type_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX attachments_attachment_content_type_id ON attachments_attachment USING btree (content_type_id);


--
-- Name: attachments_attachment_creator_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX attachments_attachment_creator_id ON attachments_attachment USING btree (creator_id);


--
-- Name: auth_group_permissions_group_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX auth_group_permissions_group_id ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX auth_group_permissions_permission_id ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX auth_user_groups_group_id ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX auth_user_groups_user_id ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_permission_id ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_user_id ON auth_user_user_permissions USING btree (user_id);


--
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX django_admin_log_content_type_id ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX django_admin_log_user_id ON django_admin_log USING btree (user_id);


--
-- Name: django_comment_flags_comment_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX django_comment_flags_comment_id ON django_comment_flags USING btree (comment_id);


--
-- Name: django_comment_flags_flag; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX django_comment_flags_flag ON django_comment_flags USING btree (flag);


--
-- Name: django_comment_flags_flag_like; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX django_comment_flags_flag_like ON django_comment_flags USING btree (flag varchar_pattern_ops);


--
-- Name: django_comment_flags_user_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX django_comment_flags_user_id ON django_comment_flags USING btree (user_id);


--
-- Name: django_comments_content_type_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX django_comments_content_type_id ON django_comments USING btree (content_type_id);


--
-- Name: django_comments_site_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX django_comments_site_id ON django_comments USING btree (site_id);


--
-- Name: django_comments_user_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX django_comments_user_id ON django_comments USING btree (user_id);


--
-- Name: django_flatpage_sites_flatpage_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX django_flatpage_sites_flatpage_id ON django_flatpage_sites USING btree (flatpage_id);


--
-- Name: django_flatpage_sites_site_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX django_flatpage_sites_site_id ON django_flatpage_sites USING btree (site_id);


--
-- Name: django_flatpage_url; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX django_flatpage_url ON django_flatpage USING btree (url);


--
-- Name: django_flatpage_url_like; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX django_flatpage_url_like ON django_flatpage USING btree (url varchar_pattern_ops);


--
-- Name: django_session_expire_date; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX django_session_expire_date ON django_session USING btree (expire_date);


--
-- Name: money_exchangerate_from_curr_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX money_exchangerate_from_curr_id ON money_exchangerate USING btree (from_curr_id);


--
-- Name: money_exchangerate_to_curr_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX money_exchangerate_to_curr_id ON money_exchangerate USING btree (to_curr_id);


--
-- Name: money_portfolio_client_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX money_portfolio_client_id ON money_portfolio USING btree (client_id);


--
-- Name: money_transaction_exchange_rate_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX money_transaction_exchange_rate_id ON money_transaction USING btree (exchange_rate_id);


--
-- Name: money_transaction_portfolio_id; Type: INDEX; Schema: public; Owner: web; Tablespace: 
--

CREATE INDEX money_transaction_portfolio_id ON money_transaction USING btree (portfolio_id);


--
-- Name: attachments_attachment_content_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY attachments_attachment
    ADD CONSTRAINT attachments_attachment_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachments_attachment_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY attachments_attachment
    ADD CONSTRAINT attachments_attachment_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_288599e6; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT content_type_id_refs_id_288599e6 FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_728de91f; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_728de91f FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_d5868a5; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_comments
    ADD CONSTRAINT content_type_id_refs_id_d5868a5 FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comment_flags_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_comment_flags
    ADD CONSTRAINT django_comment_flags_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES django_comments(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comment_flags_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_comment_flags
    ADD CONSTRAINT django_comment_flags_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_comments
    ADD CONSTRAINT django_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_flatpage_sites_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_flatpage_sites
    ADD CONSTRAINT django_flatpage_sites_site_id_fkey FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: flatpage_id_refs_id_3f17b0a6; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_flatpage_sites
    ADD CONSTRAINT flatpage_id_refs_id_3f17b0a6 FOREIGN KEY (flatpage_id) REFERENCES django_flatpage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_3cea63fe; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT group_id_refs_id_3cea63fe FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: money_exchangerate_from_curr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY money_exchangerate
    ADD CONSTRAINT money_exchangerate_from_curr_id_fkey FOREIGN KEY (from_curr_id) REFERENCES money_currency(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: money_exchangerate_to_curr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY money_exchangerate
    ADD CONSTRAINT money_exchangerate_to_curr_id_fkey FOREIGN KEY (to_curr_id) REFERENCES money_currency(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: money_portfolio_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY money_portfolio
    ADD CONSTRAINT money_portfolio_client_id_fkey FOREIGN KEY (client_id) REFERENCES money_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: money_transaction_exchange_rate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY money_transaction
    ADD CONSTRAINT money_transaction_exchange_rate_id_fkey FOREIGN KEY (exchange_rate_id) REFERENCES money_exchangerate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: money_transaction_portfolio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY money_transaction
    ADD CONSTRAINT money_transaction_portfolio_id_fkey FOREIGN KEY (portfolio_id) REFERENCES money_portfolio(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_7248df08; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_comments
    ADD CONSTRAINT site_id_refs_id_7248df08 FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_63b2844f; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY admin_tools_menu_bookmark
    ADD CONSTRAINT user_id_refs_id_63b2844f FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_7b78c8a; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY admin_tools_dashboard_preferences
    ADD CONSTRAINT user_id_refs_id_7b78c8a FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_7ceef80f; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT user_id_refs_id_7ceef80f FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_c8665aa; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT user_id_refs_id_c8665aa FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_dfbab7d; Type: FK CONSTRAINT; Schema: public; Owner: web
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT user_id_refs_id_dfbab7d FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

